package restaurant;

import java.util.Scanner;

public class Administrator {
    // public  int locuri_tot;
    public static int locuri_tot=300;
    public static String prog_zi_ince="luni",prg_zi_sfar="duminica";
    public static double data;
    public static double prg_ora_ince=8.00, prg_ora_sfar=22.00;
    public static double cifra_afacerii=200.000;
    public static double profit_an=100.000;
    public static double venituri=5.000;
    public static double cheltuieli=2.000;
    Scanner tst = new Scanner(System.in);

    public Administrator() {

        prog_zi_ince = "";
        data=0.f;
        prg_zi_sfar="";
        prg_ora_ince= 0;
        prg_ora_sfar=0;
        
    }

   
    public static String getProg_zi_ince() {
        return prog_zi_ince;
    }
    
    public static String getProg_zi_sfar(){
        return prg_zi_sfar;
    }
    public static void setPrg_zi_sfar(String sfarsit){
        prg_zi_sfar=sfarsit;
    }
    public static void setPrg_zi_ince(String zi) {
        prog_zi_ince =zi;
    }
    public static void setData(double d){
        data=d;
    }
    public static double getDate(){
        return data;
    }

    public static double getPrg_ora_ince() {
        return prg_ora_ince;
    }

    public static void setPrg_ora_ince(double ora) {
        prg_ora_ince=ora;
    }

    public static double getCifra_afacerii() {
        return cifra_afacerii;
    }

    public static void setCifra_afacerii(double cifa) {
        cifra_afacerii = cifa;
    }

    public static double getProfit_an() {
        return profit_an;
    }

    public static void setProfit_an(double profit) {
        profit_an = profit;
    }

    public static double getVenituri() {
        return venituri;
    }

    public static void setVenituri(double venit) {
        venituri = venit;
    }

    public static double getCheltuieli() {
        return cheltuieli;
    }

    public static void setCheltuieli(double chelt) {
        cheltuieli = chelt;
    }

   public static void setLocuri_tot(int locuri_totale){
       locuri_tot=locuri_totale;
   }
    public void afisare() {
        System.out.println("Programul restaurantului este: " + prog_zi_ince+"-"+prg_zi_sfar + " intre orele " +prg_ora_ince+"-"+prg_ora_sfar);
        System.out.println("Informatiile financiare ale firmei sunt: " + cifra_afacerii + " veniturile medii ale firmei pe un an sunt: " + venituri);
        System.out.println("Cheltuielile  medii ale firmei sunt: " + cheltuieli + " iar profitul anual al firmei este: " + profit_an);
        System.out.println("Locurile totale la restaurantul nostru sunt: "+locuri_tot);

    }
public void comparatie_zile(){
    if(prg_ora_ince<Date_rezervare.ora || prg_ora_sfar>Date_rezervare.ora)
        System.out.println("Evenimentul nu poate fi programat la data aleasa");
    if(Date_rezervare.zi==data)
        System.out.println("Pe data aleasa restaurantul nu este deschis");
    
}
    public void adaugare_clienti_rezervari() {
        Client[] cl1;
        Date_rezervare[] da;
       
        int n, i,nr_loc_disponib=300;
        Scanner tst = new Scanner(System.in);
  
        System.out.println("Numarul de clienti ai restaurantului sunt: ");
        n = tst.nextInt();
        cl1 = new Client[n];
        da = new Date_rezervare[n];
        for (i = 0; i < n; i++) {
        
            da[i] = new Date_rezervare();
        }
        System.out.println("Adaug un nou client");
        for (i = 0; i < n; i++)
        {
           cl1[i]=new Client();
            cl1[i].adaug_client();
            nr_loc_disponib--;
            
            da[i]= new Date_rezervare();
            da[i].adaug_date();comparatie_zile();
            if(Date_rezervare.nr_persoane>nr_loc_disponib)
                System.out.println("Nu exista locuri pentru un astfel de eveniment");
            
        }
        System.out.println("Rezervarile sunt: ");
        for (i = 0; i < n; i++) 
        {
            cl1[i].afisare();
            da[i].afisare();
        }

    }

}
