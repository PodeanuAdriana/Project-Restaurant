package restaurant;
 import java.util.Scanner;
public class Aperitive extends Meniu {

    public static double itemPrice;

    public Aperitive() {
    }

    public static double getItemPrice() {
        return itemPrice;
    }

    public static void setItemPrice(double itemPrice) {
        Mic_dejun.itemPrice = itemPrice;
    }

    public void aperitive() {
        System.out.println("Welcome!Introdu optiunea ta ");
        System.out.println("1. Scallion and Caramelized Onion Dip............ 5 eur");
        System.out.println("2. Caviar...............15 eur");
        System.out.println("3.Beer Dip.......10 eur");
        System.out.println("4. Easy Creamy Prosciutto Cracker Appetizer.......5 eur");
        System.out.println(" 5. Iesire din meniul zilei");
        int op2,  cantitate = 0;
        Scanner input = new Scanner(System.in);
        op2 = input.nextInt();
        while (op2 != 5) {

            switch (op2) {
                case 1:
                    System.out.println("Ai comandat Scallion and Caramelized Onion Dip in valoare de 5 eur ");

                    System.out.println("Cate portii de Scallion and Caramelized Onion Dip doriti?");
                    cantitate = input.nextInt();
                    total = total + (5 * cantitate);

                    System.out.println("Daca doriti sa mai comandati, apasati 1");
                    again = input.next();
                    if (!again.equalsIgnoreCase("1")) {
                    } else {
                        aperitive();
                    }
                    System.out.println("Totalul este" + total);

                    break;

                case 2:
                    System.out.println("Ai comandat Caviar in valoare de 15 eur ");

                    System.out.println("Cate portii de Caviar doriti?");
                    cantitate = input.nextInt();
                    total = total + (15 * cantitate);

                    System.out.println("Daca doriti sa mai comandati, apasati 1");
                    again = input.next();
                    if (!again.equalsIgnoreCase("1")) {
                    } else {
                        aperitive();
                    }
                    System.out.println("Totalul este" + total);

                    break;

                case 3:
                    System.out.println("Ai comandat Beer Dip in valoare de 10 eur ");

                    System.out.println("Cate portii de Beer Dip doriti?");
                    cantitate = input.nextInt();
                    total = total + (10 * cantitate);

                    System.out.println("Daca doriti sa mai comandati, apasati 1");
                    again = input.next();
                    if (!again.equalsIgnoreCase("1")) {
                    } else {
                        aperitive();
                    }
                    System.out.println("Totalul este" + total);

                    break;

                case 4:
                    System.out.println("Ai comandat Easy Creamy Prosciutto Cracker Appetizer in valoare de 5 eur ");

                    System.out.println("Cate portii de Easy Creamy Prosciutto Cracker Appetizer doriti?");
                    cantitate = input.nextInt();
                    total = total + (5 * cantitate);

                    System.out.println("Daca doriti sa mai comandati, apasati 1");
                    again = input.next();
                    if (!again.equalsIgnoreCase("1")) {
                    } else {
                        aperitive();
                    }
                    System.out.println("Totalul este" + total);

                    break;
            }
        }

    }
}
