
package restaurant;
import java.util.Scanner;

public class Bauturi extends Meniu {
     public static double itemPrice;
    
     public Bauturi() {
    }

    public static double getItemPrice() {
        return itemPrice;
    }

    public static void setItemPrice(double itemPrice) {
        Mic_dejun.itemPrice = itemPrice;
    }
  
    
    public void bauturi(){
        System.out.println("Welcome!Introdu optiunea ta ");
        System.out.println("1. Coca Cola............3 eur");
        System.out.println("2. Lemon Pepsi...............3  eur");
        System.out.println("3.Fanta.......3  eur");
        System.out.println("4. Apa.......1 eur");
        System.out.println(" 5. Iesire din meniul zilei");
        int op2,s=0, cantitate = 0;
       Scanner input = new Scanner(System.in);
       op2=input.nextInt();
       while(op2!=5){
           
           switch(op2){
               case 1: 
                   System.out.println("Ai comandat Coca Cola in valoare de 3 eur ");
                   s=s+3;
                   
                   System.out.println("Cate Coca Cola doriti?");
                   cantitate = input.nextInt();
                   total = total + (3*cantitate);
                   
                   System.out.println("Daca doriti sa mai comandati, apasati 1");
                   again = input.next();
                   if(!again.equalsIgnoreCase("1")){
                   } else {
                       bauturi();
                   }
                   break;
                   
               case 2:
                   System.out.println("Ai comandat Lemon Pespi in valoare de 3 eur ");
                   s=s+3;
                   
                   System.out.println("Cate Lemon Pespi doriti?");
                   cantitate = input.nextInt();
                   total = total + (3*cantitate);
                   
                   System.out.println("Daca doriti sa mai comandati, apasati 1");
                   again = input.next();
                   if(!again.equalsIgnoreCase("1")){
                   } else {
                       bauturi();
                   }
                   break;
                   
               case 3:
                   System.out.println("Ai comandat Fanta in valoare de 3 eur ");
                   s+=3;
                   System.out.println("Cate Fanta doriti?");
                   cantitate = input.nextInt();
                   total = total + (3*cantitate);
                   
                   System.out.println("Daca doriti sa mai comandati, apasati 1");
                   again = input.next();
                   if(!again.equalsIgnoreCase("1")){
                   } else {
                       bauturi();
                   }
                   break;
                   
               case 4:
                   System.out.println("Ai comandat Apa in valoare de 1 eur ");
                   s+=3;
                   
                   System.out.println("Cate sticle de Apa doriti?");
                   cantitate = input.nextInt();
                   total = total + (1*cantitate);
                   
                   System.out.println("Daca doriti sa mai comandati, apasati 1");
                   again = input.next();
                   if(!again.equalsIgnoreCase("1")){
                   } else {
                       bauturi();
                   }
                   break;
           }
       }
       

    }
}
