
package restaurant;

import java.util.Scanner;
public class Cina extends Meniu {
    public static double itemPrice;
    
     public Cina() {
    }

    public static double getItemPrice() {
        return itemPrice;
    }

    public static void setItemPrice(double itemPrice) {
        Cina.itemPrice = itemPrice;
    }
  
    
    public void cina(){
        System.out.println("Welcome!Introdu optiunea ta ");
        System.out.println("1. Piccata............20 eur");
        System.out.println("2. Spaghette alla bolognese...............10  eur");
        System.out.println("3.Cartofi frantuzesti.......5  eur");
        System.out.println("4. Somon afumat.......15 eur");
        System.out.println(" 5. Iesire din meniul zilei");
        int op2,s=0, cantitate = 0;
       Scanner input = new Scanner(System.in);
       op2=input.nextInt();
       while(op2!=5){
           
           switch(op2){
               case 1: 
                   System.out.println("Ai comandat Piccata in valoare de 20 eur ");
                   
                   System.out.println("Cate portii de Picatta doriti?");
                   cantitate = input.nextInt();
                   total = total + (20*cantitate);
                   
                   System.out.println("Daca doriti sa mai comandati, apasati 1");
                   again = input.next();
                   if(!again.equalsIgnoreCase("1")){
                   } else {
                       cina();
                   }
                   System.out.println("Totalul este"+total);
                   
                   break;
                   
               case 2:
                   System.out.println("Ai comandat  portii de Spaghette alla bolognese in valoare de 10 eur ");
                   
                   System.out.println("Cate Spaghette alla bolognese doriti?");
                   cantitate = input.nextInt();
                   total = total + (10*cantitate);
                   
                   System.out.println("Daca doriti sa mai comandati, apasati 1");
                   again = input.next();
                   if(!again.equalsIgnoreCase("1")){
                   } else {
                       cina();
                   }
                   System.out.println("Totalul este"+total);
                   
                   break;
                   
               case 3:
                   System.out.println("Ai comandat Cartofi frantuzesti in valoare de 5 eur ");
                   
                   System.out.println("Cate portii de Cartofi frantuzesti doriti?");
                   cantitate = input.nextInt();
                   total = total + (5*cantitate);
                   
                   System.out.println("Daca doriti sa mai comandati, apasati 1");
                   again = input.next();
                   if(!again.equalsIgnoreCase("1")){
                   } else {
                       cina();
                   }
                   System.out.println("Totalul este"+total);
                   
                   break;
               case 4:
                   System.out.println("Ai comandat Somon afumat in valoare de 15 eur ");
                   
                   System.out.println("Cate portii de Somon afumat doriti?");
                   cantitate = input.nextInt();
                   total = total + (15*cantitate);
                   
                   System.out.println("Daca doriti sa mai comandati, apasati 1");
                   again = input.next();
                   if(!again.equalsIgnoreCase("1")){
                   } else {
                       cina();
                   }
                   System.out.println("Totalul este"+total);
                   
                   break;
           }
       }
       

    }
}
