package restaurant;

import java.util.Scanner;

public class Client {

    public String nume;
    public String prenume;
    public long nr_telefon;
    public String email;

    public Client() {

    }

    public Client(String N, String P, long tele, String mail) {
        nume = N;
        prenume = P;
        nr_telefon = tele;
        email = mail;
    }

    public Client(Client C1) {
        nume = C1.nume;
        prenume = C1.prenume;
        nr_telefon = C1.nr_telefon;
        email = C1.email;
    }

    public void setNume(String N) {
        nume = N;
    }

    public void setPrenume(String P) {
        prenume = P;
    }

    public void setNr_Telefon(long tele) {
        nr_telefon = tele;
    }

    public void setMail(String mail) {
        email = mail;
    }

    public String getNume() {
        return nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public long getNrTele() {
        return nr_telefon;
    }

    public String getMail() {
        return email;
    }

    public void afisare() {
        System.out.println("Numele si prenumele dvs este: " + nume + " " + prenume + " nr de telefon pt contactare este: " + nr_telefon
                + " email-ul dvs este: " + email);
    }

    public void adaug_client() {
        String n;
        String p;
        long nr;
        String e;

        int i;
        Scanner tst = new Scanner(System.in);
        System.out.println("Numele si prenumele clientului este: ");
        n = tst.nextLine();
        this.setNume(n);
        p = tst.nextLine();
        this.setPrenume(p);
        System.out.println("Numarul de telefon al  clientului este : ");

        nr = tst.nextInt();
        this.setNr_Telefon(nr);
        if (nr > 10 || nr < 10) {
            System.out.println("Numarul este incorect!Va rugam reintroduceti!");
        }
        nr = tst.nextLong();
        tst.nextLine();
        this.setNr_Telefon(nr);
        
        System.out.println("Email-ul clientului este: ");
        e = tst.nextLine();
        this.setMail(e);
    }

}
