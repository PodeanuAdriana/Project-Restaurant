package restaurant;
import java.util.Scanner;



public class Date_rezervare extends Client{
   
    public static  int nr_persoane=0;
    public  static double ora;
    public static  double zi;
    public  static String zisaptamana;
    public  static boolean eveniment = false;
    public int loc_diponi=300;
   // public boolean confirmare=true;
    public Date_rezervare(){
        
    }
   public int loc_disponi;
    public double getOra() {
        return ora;
    }
   

    public double getZi() {
        return zi;
    }

    public String getZisaptamana() {
        return zisaptamana;
    }

    public boolean isEveniment() {
        return eveniment;
    }

   /* public boolean isConfirmare() {
        return confirmare;
    }*/
   
    public Date_rezervare(String N, String P, long tele, String mail,int loc,double O, double Z, String ZS, boolean ev) 
    { 
        super(N,P,tele,mail);
//        locuri_totale=loc;
        ora = O;
        zi = Z;
        zisaptamana = ZS;
        eveniment = ev;
        //confirmare = conf;
    }

    public void Date_rezervare(Date_rezervare Da) {
        //locuri_totale=Da.locuri_totale;
        ora = Da.ora;
        zi = Da.zi;
        zisaptamana = Da.zisaptamana;
        eveniment = Da.eveniment;
        //loc_disponi=locuri_totale--;
        //confirmare = Da.confirmare;
    }
    

   

   

    public void setOra(double O) {
        ora = O;
    }

    public void setZi(double Z) {
        zi = Z;
    }

    public void setZisaptamana(String ZS) {
        zisaptamana = ZS;
    }

    public void setEveniment(boolean ev) {
        eveniment = ev;
    }

    /*public void setConfirmare(boolean conf) {
        confirmare = conf;
    }*/

    /*public void rezervare() {
        //de regandit
        if (confirmare == true) {
            System.out.println("Rezervarea dvs a fost facuta!");
        } else {
            System.out.println("Rezervarea nu a fost  facuta! ");
        }
    }*/
   
    public void anulare_eveniment() {
        if (eveniment == false) {
            ora = 0.0;
            zi = 0.0;
            zisaptamana = "";
            //confirmare = false;
         

            System.out.println("Rezervearea evenimentului este anulata!");
        } else {
            System.out.println("Evenimentul inca exista!");
        }
    }
   

  
    @Override
    public void afisare() {
        super.afisare();
        System.out.println("Rezervarea este facuta in ziua de: " + zisaptamana + " pe data de: " + zi + " la ora de: " + ora + " daca aveti eveniment mare " + eveniment );
    }

   public  static void adaug_date(){
       double o,or;
       double z;
       boolean ev=false;
       //boolean co=false;
       int a;
       Scanner tst = new Scanner(System.in);
       System.out.println("Ora  de inceput evenimentului este: ");
       o=tst.nextDouble();
       System.out.println("Ora de sfarsit a evenimentului este:");
       or=tst.nextDouble();
       System.out.println("Ziua evenimentului este: ");
       z=tst.nextDouble();
       System.out.println("Este eveniment mare?");
       ev=tst.nextBoolean();
      // System.out.println("Este confiramre?");
      // co=tst.nextBoolean();
      if(ev==true)
          System.out.println("Cate locuri doriti sa rezervati");
          nr_persoane=tst.nextInt();
         
          //comparatia sa vad daca rezervarea in restaurant este valabila pe ziua respectiva
          //comparatia pt orele in care restaurantul lucreaza 
       
       
   }
  

}
