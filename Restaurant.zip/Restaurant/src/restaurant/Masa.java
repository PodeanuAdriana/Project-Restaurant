package restaurant;
public class Masa {
    //cele 2 variabile
    private int nr_persoane;
    private String locatie;
    //constructor implicit
    public Masa() {
        this.nr_persoane=0;
        this.locatie="";
    }
    //constructor explicit
    public Masa(int nr_persoane, String locatie) {
        this.nr_persoane = nr_persoane;
        this.locatie = locatie;
    }
    //geter si seter pentru fiecare variabila in parte
    public int getNr_persoane() {
        return nr_persoane;
    }

    public void setNr_persoane(int nr_persoane) {
        this.nr_persoane = nr_persoane;
    }

    public String getLocatie() {
        return locatie;
    }

    public void setLocatie(String locatie) {
        this.locatie = locatie;
    }
    
    
}