
package restaurant;

import java.util.*;
public class Meniu {
   Scanner scane= new Scanner(System.in);
    public static String again;
    public static int choice;
    public static double total, pay;
   // Mic_dejun m1 = new Mic_dejun();
    //Meniul_zilei m2 = new Meniul_zilei();
    //Aperitive ap= new Aperitive();
    //Bauturi b1= new Bauturi();
    //Desert d1 = new Desert();
    //Cina c1= new Cina();
   public void comanda(){
       System.out.println("Alegeti: ");
       System.out.println("1. Mic dejun" );
       System.out.println("2. Meniul zilei");
       System.out.println("3. Aperitiv");
       System.out.println("4. Bauturi");
       System.out.println("5. Deserturi");
       System.out.println("6. Cina");
       System.out.println("7. Iesire");
       System.out.println("Selectati ce doriti sa comandati! ");
       choice = scane.nextInt();
       
       while(choice!=7){
           switch(choice){
               case 1:
                   System.out.println("Ati ales Micul dejun ");
                   //introduc subclasa ca sa o apelez aici
                   
                   Mic_dejun m1 = new Mic_dejun();
                   m1.meniu_mic_dejun();
                   break;
                   
               case  2:
                   System.out.println("Ati ales Meniul zilei ");
                   
                   Meniul_zilei m2 = new Meniul_zilei();
                   m2.meniul_zilei();
                   break;
                   
               case 3:
                   System.out.println("Ati ales aperitiv ");
                   
                   Aperitive m3 = new Aperitive();
                   m3.aperitive();
                   break;
                   
               case 4:
                   System.out.println("Ati selectat bauturi ");
                   
                   Desert m4 = new Desert();
                   m4.desert();
                   break;
                   
               case 5:
                   System.out.println("Ati ales deserturi ");
                   
                   Bauturi m5 = new Bauturi();
                   m5.bauturi();
                   break;
                   
                   case 6:
                   System.out.println("Ati ales Cina ");
                   //introduc subclasa ca sa o apelez aici
                   
                   Cina m6 = new Cina();
                   m6.cina();
                   break;
           }
           // calculez totalul comenzilor date 
           
       }
   }

    public Meniu() {
    }

    public static String getAgain() {
        return again;
    }

    public static void setAgain(String again) {
        Meniu.again = again;
    }

    public static int getChoice() {
        return choice;
    }

    public static void setChoice(int choice) {
        Meniu.choice = choice;
    }

    public static double getPay() {
        return pay;
    }

    public static void setPay(double pay) {
        Meniu.pay = pay;
    }
    
}