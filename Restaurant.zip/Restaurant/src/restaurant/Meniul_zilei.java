package restaurant;
 import java.util.Scanner;
public class Meniul_zilei extends Meniu {

    public static double itemPrice;

    public Meniul_zilei() {
    }

    public static double getItemPrice() {
        return itemPrice;
    }

    public static void setItemPrice(double itemPrice) {
        Mic_dejun.itemPrice = itemPrice;
    }

    public void meniul_zilei() {
        System.out.println("Welcome!Introdu optiunea ta ");
        System.out.println("1. Minty roast veg & hummus salad............20 eur");
        System.out.println("2. Spanish meatball & butter bean stew...............15 eur");
        System.out.println("3.Spicy roast veg & lentils.......25 eur");
        System.out.println("4. Honey mustard grilled salmon.......40 eur");
        System.out.println(" 5. Iesire din meniul zilei");
        int op2, s = 0, cantitate = 0;
        Scanner input = new Scanner(System.in);
        op2 = input.nextInt();
        while (op2 != 5) {

            switch (op2) {
                case 1:
                    System.out.println("Ai comandat Minty roast veg & hummus salad in valoare de 20 eur ");

                    System.out.println("Cate portii de Minty roast veg & hummus salad doriti?");
                    cantitate = input.nextInt();
                    total = total + (20 * cantitate);

                    System.out.println("Daca doriti sa mai comandati, apasati 1");
                    again = input.next();
                    if (!again.equalsIgnoreCase("1")) {
                    } else {
                        meniul_zilei();
                    }
                    System.out.println("Totalul este" + total);

                    break;

                case 2:
                    System.out.println("Ai comandat Spanish meatball & butter bean stew in valoare de 15 eur ");

                    System.out.println("Cate portii de Spanish meatball & butter bean stew doriti?");
                    cantitate = input.nextInt();
                    total = total + (15 * cantitate);

                    System.out.println("Daca doriti sa mai comandati, apasati 1");
                    again = input.next();
                    if (!again.equalsIgnoreCase("1")) {
                    } else {
                        meniul_zilei();
                    }
                    System.out.println("Totalul este" + total);

                    break;

                case 3:
                    System.out.println("Ai comandat Spicy roast veg & lentils in valoare de 25 eur ");

                    System.out.println("Cate portii de Spicy roast veg & lentils doriti?");
                    cantitate = input.nextInt();
                    total = total + (25 * cantitate);

                    System.out.println("Daca doriti sa mai comandati, apasati 1");
                    again = input.next();
                    if (!again.equalsIgnoreCase("1")) {
                    } else {
                        meniul_zilei();
                    }
                    System.out.println("Totalul este" + total);

                    break;

                case 4:
                    System.out.println("Ai comandat Honey mustard grilled salmon in valoare de 40 eur ");

                    System.out.println("Cate portii de Honey mustard grilled salmon doriti?");
                    cantitate = input.nextInt();
                    total = total + (40 * cantitate);

                    System.out.println("Daca doriti sa mai comandati, apasati 1");
                    again = input.next();
                    if (!again.equalsIgnoreCase("1")) {
                    } else {
                        meniul_zilei();
                    }
                    System.out.println("Totalul este" + total);

                    break;
            }
        }
    }}
