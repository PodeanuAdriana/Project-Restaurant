
package restaurant;
import java.util.Scanner;

public class Mic_dejun extends Meniu {
   public static double itemPrice;

    public Mic_dejun() {
    }

    public static double getItemPrice() {
        return itemPrice;
    }

    public static void setItemPrice(double itemPrice) {
        Mic_dejun.itemPrice = itemPrice;
    }
  
    public void meniu_mic_dejun(){
        System.out.println("Welcome!Introdu optiunea ta ");
        System.out.println("1. Clatite ciocolata............20 eur");
        System.out.println("2. Oua...............10 eur");
        System.out.println("3.Sandwich Toast.......5 eur");
        System.out.println("4. Omlette Taste.......15 eur");
        System.out.println(" 5. Iesire din mic dejun");
        int op2,s=0, cantitate = 0;
       Scanner input = new Scanner(System.in);
       op2=input.nextInt();
       while(op2!=5){
           
           switch(op2){
               case 1: 
                   System.out.println("Ai comandat Pancake in valoare de 20 eur ");
                  
                   System.out.println("Cate clatite cu ciocolata doriti?");
                   cantitate = input.nextInt();
                   total = total + (20*cantitate);
                   
                   System.out.println("Daca doriti sa mai comandati, apasati 1, daca vreti sa iesiti apasati 5");
                   again = input.next();
                   if(!again.equalsIgnoreCase("1")){
                   } else {
                       meniu_mic_dejun();
                   }
                   System.out.println("Totalul este"+total);
                   
                   break;

               case 2:
                   System.out.println("Ai comandat Oua in valoare de 10 eur ");
                   
                   System.out.println("Cate oua doriti?");
                   cantitate = input.nextInt();
                   total = total + (10*cantitate);
                   
                   System.out.println("Daca doriti sa mai comandati, apasati 1,daca vreti sa iesiti apasati 5");
                   again = input.next();
                   if(!again.equalsIgnoreCase("1")){
                   } else {
                       meniu_mic_dejun();
                   }
                   System.out.println("Totalul este"+total);
                   
                   break;
               case 3:
                   System.out.println("Ai comandat Sandwich Toast in valoare de 5 eur ");
                   
                   System.out.println("Cate Sandwich Toast doriti?");
                   cantitate = input.nextInt();
                   total = total + (5*cantitate);
                   
                   System.out.println("Daca doriti sa mai comandati, apasati 1,daca vreti sa iesiti apasati 5");
                   again = input.next();
                   if(!again.equalsIgnoreCase("1")){
                   } else {
                       meniu_mic_dejun();
                   }
                   System.out.println("Totalul este"+total);
                   
                   break;
               case 4:
                   System.out.println("Ai comandat Omlette Taste in valoare de 15 eur ");
                   
                   System.out.println("Cate Omlette Taste doriti?");
                   cantitate = input.nextInt();
                   total = total + (15*cantitate);
                   
                   System.out.println("Daca doriti sa mai comandati, apasati 1 daca doriti sa iesiti apasati 5");
                   again = input.next();
                   if(!again.equalsIgnoreCase("1")){
                   } else {
                       meniu_mic_dejun();
                   }
                   System.out.println("Totalul este"+total);
                   
                   break;
                   
           }
       }
       

    }
    
}
