
package restaurant;

public class Pachete_Speciale extends Masa {
    private boolean parcare;
    private boolean scaun_copil;
    private String meniu_preferential;

    public Pachete_Speciale() {
        this.parcare=false;
        this.scaun_copil=false;
        this.meniu_preferential="";
    }

    public Pachete_Speciale(int nr_persoane, String locatie) {
        super(nr_persoane, locatie);
        this.parcare=false;
        this.scaun_copil=false;
        this.meniu_preferential="";
    }

    public Pachete_Speciale(boolean parcare, boolean scaun_copil, String meniu_preferential) {
        this.parcare = parcare;
        this.scaun_copil = scaun_copil;
        this.meniu_preferential = meniu_preferential;
    }

    public Pachete_Speciale(boolean parcare, boolean scaun_copil, String meniu_preferential, int nr_persoane, String locatie) {
        super(nr_persoane, locatie);
        this.parcare = parcare;
        this.scaun_copil = scaun_copil;
        this.meniu_preferential = meniu_preferential;
    }
 public void afisare(){
     System.out.println("Optiunea dvs pentru parcare este:"+parcare+"optiunea dvs. pentru sacun_copil este:"+scaun_copil+"optiunea dvs. pentru meniu_preferential este: "+meniu_preferential);
 }
    public boolean isParcare() {
        return parcare;
    }

    public void setParcare(boolean parcare) {
        this.parcare = parcare;
    }

    public boolean isScaun_copil() {
        return scaun_copil;
    }

    public void setScaun_copil(boolean scaun_copil) {
        this.scaun_copil = scaun_copil;
    }

    public String getMeniu_preferential() {
        return meniu_preferential;
    }

    public void setMeniu_preferential(String meniu_preferential) {
        this.meniu_preferential = meniu_preferential;
    }
       
}
