package restaurant;

import java.util.Scanner;

public class Restaurant {

    public static void main(String[] args) {
        Client cl = new Client();
        Date_rezervare d1 = new Date_rezervare();
        Masa m1 = new Masa();
        Meniu men1 = new Meniu();
        Pachete_Speciale p = new Pachete_Speciale();

        d1.afisare();
        Administrator adm = new Administrator();

        int i, n;
        Scanner tst = new Scanner(System.in);

        int op = 0;
        System.out.println("Apasati tasta 1 daca vreti sa intrati pe contul de administrator");
        System.out.println("Apasati tasta 2 daca vreti sa intrati pe contul de client");
        System.out.println("Apasati tasta 3 pentru a accesa contul pentru institutii publice");
        System.out.println("Apasati 4 pentru iesire");
        op = tst.nextInt();
        while (op != 4) {
            switch (op) {
                case 1: {
                    int pass = 1234567, pass1;
                    System.out.println("Introduceti parola pentru a intra in cont: ");
                    pass1 = tst.nextInt();
                    if (pass == pass1) {
                        System.out.println("Ati intrat in contul administrator");
                    }
                    System.out.println("Introduceti lista de clienti cu datele necesare");
                    adm.adaugare_clienti_rezervari();
                    adm.afisare();
                    break;
                }
                case 2: {
                    boolean confirm = false;
                    System.out.println("Ati accesat contul client");
                    System.out.println("Adaug un nou client");
                    System.out.println("Daca doriti sa resetati numele apasati 2");
                    System.out.println("Daca vreti sa resetati prenumele apasati 3");
                    System.out.println("Daca vreti sa resetati numarul de telefon apasati 4");
                    System.out.println("Daca doriti sa resetati mailul apasati 5");
                    System.out.println("Daca doriti sa schimbati locatia mesei apasti 6");
                    System.out.println("Daca doriti sa resetati optiunea pt parcare apasati 7");
                    System.out.println("Daca doriti sa resetati optiunea pt scaun copil apasati 8");
                    System.out.println("Daca doriti sa resetati optiunea pt meniu preferential apasati 9");
                    System.out.println("Introsuceti 10 pt iesire");
                    int op2 = 0;
                    op2 = tst.nextInt();
                    while (op2 != 10) {
                        switch (op2) {
                            case 1: {
                                cl.adaug_client();
                                d1.adaug_date();

                                String locatie;
                                locatie = tst.nextLine();
                                m1.setLocatie(locatie);
                                int nr_persoane;
                                nr_persoane = tst.nextInt();
                                m1.setNr_persoane(nr_persoane);

                                men1.comanda();

                                p.afisare();
                                break;
                            }
                            case 2: {
                                String nume;
                                nume = tst.nextLine();
                                cl.setNume(nume);
                                break;
                            }
                            case 3: {
                                String prenume;
                                prenume = tst.nextLine();
                                cl.setPrenume(prenume);
                                break;
                            }
                            case 4: {
                                long nr_tele;
                                nr_tele = tst.nextLong();
                                cl.setNr_Telefon(nr_tele);
                                break;
                            }
                            case 5: {
                                String mail;
                                mail = tst.nextLine();
                                cl.setMail(mail);
                                break;
                            }
                            case 6: {

                                Masa m5 = new Masa();
                                m5.setLocatie("Exterior");
                                break;
                            }
                            case 7: {
                                p.setParcare(false);
                                break;
                            }
                            case 8: {
                                p.setScaun_copil(false);
                                break;
                            }
                            case 9: {
                                p.setMeniu_preferential("");
                                break;
                            }
                        }
                    }
                    break;

                }
                case 3: {
                    System.out.println("Ati accesat contul pentru institutii publice ");
                    adm.afisare();
                    break;
                }

            }

        }

    }
}
