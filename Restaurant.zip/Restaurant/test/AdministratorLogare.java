


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
//import javafx.scene.layout.;
import javafx.scene.layout.*;
import javafx.stage.*;


public class AdministratorLogare extends Application {
    
    @Override
    public void start(Stage stage) {
        
     TextField firstNameFld = new TextField();
TextField lastNameFld = new TextField();

Label firstNameLbl = new Label("Nume Administrator:");
Label lastNameLbl = new Label("Parola:");

firstNameLbl.setLabelFor(firstNameFld);

firstNameLbl.setMnemonicParsing(true);

lastNameLbl.setLabelFor(lastNameFld);

lastNameLbl.setMnemonicParsing(true);

GridPane root = new GridPane();

root.addRow(0, firstNameLbl, firstNameFld);
root.addRow(1, lastNameLbl, lastNameFld);

root.setMinSize(350, 250);

root.setStyle("-fx-padding: 10;" +

"-fx-border-style: solid inside;" +
"-fx-border-width: 2;" +
"-fx-border-insets: 5;" +
"-fx-border-radius: 5;" +
"-fx-border-color: blue;");
Button Btn = new Button ("Verificare");
Btn.setOnAction(new EventHandler<ActionEvent>(){
    @Override
    public void handle(ActionEvent e){
        System.out.println("Ai apasat verificare!");
    }
});
Btn.setDefaultButton(true);
HBox buttonBox = new HBox();
buttonBox.getChildren().addAll(Btn);
buttonBox.setSpacing(15);
VBox cale =  new VBox();
//cale.getChildren.addAll(buttonBox);
cale.setSpacing(15);
cale.setMinSize(350,250);
cale.setStyle("-fx-padding: 10;" +
"-fx-border-style: solid inside;" +
"-fx-border-width: 2;" +
"-fx-border-insets: 5;" +
"-fx-border-radius: 5;" +
"-fx-border-color: blue;");

Scene scene = new Scene(root);


stage.setScene(scene);

stage.setTitle("Administrator Logare");

stage.show();
    }

  
    public static void main(String[] args) {
        launch(args);
    }
    
}
