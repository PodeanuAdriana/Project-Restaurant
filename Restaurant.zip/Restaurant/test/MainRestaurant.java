

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.*;

public class MainRestaurant extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {

        Label firstNameLbl = new Label("Restaurant Blue Sky");
        Label lastNameLbl = new Label("Strada Florilor Nr43");
        GridPane root = new GridPane();
        root.addRow(0, firstNameLbl);
        root.addRow(1, lastNameLbl);
        root.setMinSize(1000, 600);
        root.setStyle("-fx-padding: 20;"
                + "-fx-border-style: solid inside;"
                + "-fx-border-width: 5;"
                + "-fx-border-insets: 5;"
                + "-fx-border-radius: 5;"
                + "-fx-border-color: blue;");
          Button adm = new Button("adm");
          adm.setText("Administrator");
          adm.setOnAction( new EventHandler<ActionEvent>(){
              @Override
              public void handle(ActionEvent e)
              {System.out.println("Ai accesat administratorul!");
                //
              }
          });
          Button Client = new Button("Client");
          Client.setText("Client");
          Client.setOnAction(new EventHandler<ActionEvent>(){ 
              @Override
              public void handle(ActionEvent e)
              {System.out.println("Ai accesat clientul");
          }
          
          });
          Button Inst = new Button ("Institutii publice");
          Inst.setText("Institutie");
          Inst.setOnAction(new EventHandler<ActionEvent>(){
              @Override
              public void handle(ActionEvent e){
                  System.out.println("Ai accesat institutiile publice");
              }
          });
          HBox buttonBox = new HBox();
          buttonBox.getChildren().addAll(adm,Client,Inst);
          buttonBox.setSpacing(15);
            VBox cale = new VBox();
            cale.getChildren().addAll(firstNameLbl,lastNameLbl,buttonBox);
            cale.setSpacing(15);
            cale.setMinSize(350,250);
            cale.setStyle("-fx-padding: 10;"+"-fx-border-style: solid inside;" +
"-fx-border-width: 2;" +
"-fx-border-insets: 5;" +
"-fx-border-radius: 5;" +
"-fx-border-color: blue;");
            Scene scene = new Scene(cale);
            stage.setScene (scene);

            stage.setTitle (

            "Restaurant Blue Sky");
            stage.show ();

        }

    }
