

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Masa_si_Meniu extends Application {

    Label selectMasa = new Label(" Alege locatia mesei");
    Label selectMeniu = new Label("Alege meniul dupa ce alegi masa");
    Label selectMic = new Label("Alegere mic de jun");
    Label selectPranz = new Label("Alegere meniul zilei");
    Label selectCina = new Label("Alegere cinei");

    public static void main(String[] args) {
        
    }

    @Override
    public void start(Stage stage) {
        CheckBox Inte = new CheckBox("Interior");
        CheckBox Ext = new CheckBox("Exterior");
          int s=0;
        Label selectMic_de_jun = new Label("Alegeti mic de junul");
        CheckBox mic = new CheckBox("Mic de jun");
        CheckBox Pancake = new CheckBox("Pancake.........20eur");
        CheckBox Eggs = new CheckBox("Eggs...........10eur");
        CheckBox Sandwich_Toast = new CheckBox("Sandwich Toast......5eur");
        CheckBox Omlette_Taste = new CheckBox("Omlette Taste.......15eur");
        CheckBox pranz = new CheckBox("Pranz");
        CheckBox Ciorba_burta= new CheckBox("Ciorba de burta");
        CheckBox cina = new CheckBox("Cina");
        CheckBox Piccata = new CheckBox("Piccata.........20");
        CheckBox Spaghette_alla_bolognese = new CheckBox("Spaghette alla bolognese........10");
        CheckBox Cartofi_Frantuzesti = new CheckBox("Cartofi_Frantuzesti........5");
        CheckBox Somon_afumat = new CheckBox("Somon afumat.........15");
        Ext.setAllowIndeterminate(true);

        Inte.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov,
                    final Boolean value, final Boolean newValue) {
                if (newValue != null && newValue) {
                    System.out.println("Ati ales masa de la interior");
                }
            }
        });
        Ext.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov,
                    final Boolean value, final Boolean newValue) {
                if (newValue != null && newValue) {
                    System.out.println("Ati ales masa de la exterior");
                }
            }
        });
        mic.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov,
                    final Boolean value, final Boolean newValue) {
                if (newValue != null && newValue) {
                    System.out.println("Ati ales mic de jun");
                    
                }
            }
        });
          Pancake.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov,
                    final Boolean value, final Boolean newValue) {
                boolean op1=false;int s0=0;
                if (newValue != null && newValue) {
                    System.out.println("Ati ales Pancake!");
                    op1=true;
                    
                }
                if(op1==true)
                    s0=s0+20; 
            }
        });
          
            Eggs.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov,
                    final Boolean value, final Boolean newValue) {
                boolean op1=false;int s1=0;
                if (newValue != null && newValue) {
                    System.out.println("Ati ales Eggs;");
                    op1=true;
                    
                }
                if(op1==true)
                    s1=s1+10;
            }
        });
             Sandwich_Toast.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov,
                    final Boolean value, final Boolean newValue) {
                boolean op1=false;int s2=0;
                if (newValue != null && newValue) {
                    System.out.println("Ati ales Sandwich Toast;");
                    op1=true;
                    
                }
                if(op1==true)
                    s2=s2+5;
            }
        });
             Omlette_Taste.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov,
                    final Boolean value, final Boolean newValue) {
                boolean op1=false; int s3=0;
                if (newValue != null && newValue) {
                    System.out.println("Ati ales Omlette_Taste;");
                    op1=true;
                    
                }
                if(op1==true)
                    s3=s3+15;
            }
        });
            
        pranz.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov,
                    final Boolean value, final Boolean newValue) {
                if (newValue != null && newValue) {
                    System.out.println("Ati ales masa de la exterior");
                }
            }
        });
         Ciorba_burta.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov,
                    final Boolean value, final Boolean newValue) {
                boolean op1=false;
                if (newValue != null && newValue) {
                    System.out.println("Ati ales Ciorba de burta;");
                    op1=true;
                    
                }
            }
        });
        cina.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov,
                    final Boolean value, final Boolean newValue) {
                if (newValue != null && newValue) {
                    System.out.println("Ati ales cina");
                }
            }
        });
        Piccata.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov,
                    final Boolean value, final Boolean newValue) {
                boolean op1=false;
                if (newValue != null && newValue) {
                    System.out.println("Ati ales Piccata;");
                    op1=true;
                    
                }
            }
        });
        Spaghette_alla_bolognese.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov,
                    final Boolean value, final Boolean newValue) {
                boolean op1=false;
                if (newValue != null && newValue) {
                    System.out.println("Ati ales Spaghete alla bolognese;");
                    op1=true;
                    
                }
            }
        });
        Cartofi_Frantuzesti.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov,
                    final Boolean value, final Boolean newValue) {
                boolean op1=false;
                if (newValue != null && newValue) {
                    System.out.println("Ati ales Cartofi Frantuzesti;");
                    op1=true;
                    
                }
            }
        });
        Somon_afumat.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> ov,
                    final Boolean value, final Boolean newValue) {
                boolean op1=false;
                if (newValue != null && newValue) {
                    System.out.println("Ati ales Somon afumat;");
                    op1=true;
                    
                }
            }
        });
        VBox root = new VBox();
        root.getChildren().addAll(selectMasa, Inte, Ext);
        root.getChildren().addAll(selectMeniu, mic);
        root.getChildren().addAll(selectMic,Pancake,Eggs,Sandwich_Toast,Omlette_Taste);
        root.getChildren().addAll(selectCina,Piccata,Spaghette_alla_bolognese,Cartofi_Frantuzesti,Somon_afumat);
        
        root.setSpacing(20);
        root.setMinSize(1000, 600);
        root.setStyle("-fx-padding: 10;"
                + "-fx-border-style: solid inside;"
                + "-fx-border-width:2;"
                + "-fx-border-insets: 5;"
                + "-fx-border-radius: 5;"
                + "-fx-border-color:blue;");
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Alegere masa si meniu");
        stage.show();

    }

}
